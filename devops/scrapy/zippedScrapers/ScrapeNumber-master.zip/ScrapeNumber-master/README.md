# ScrapeNumber
This is a scrapy beginner project for scraping all the phone-numbers from the [mobile directory](http://www.toolsmeow.in/indian-mobile-directory/) and organizing them according to state &amp; service provider.

Finally,the scraped numbers can be searched on **truecaller** using __scrapy.Spider__ .
All the other files other than - 
* items.py
* meow.py
* truecaller.py

are created by default when you start a scrapy project.
To learn more about Scrapy,read its documentation at its [official site](http://doc.scrapy.org/en/latest/).
