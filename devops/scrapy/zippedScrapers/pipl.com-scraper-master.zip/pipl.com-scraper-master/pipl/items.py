# -*- coding: utf-8 -*-

# Define here the models for yr scraped items
#ou
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class PiplItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass
