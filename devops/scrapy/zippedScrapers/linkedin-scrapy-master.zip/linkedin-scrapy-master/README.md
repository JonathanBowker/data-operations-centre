linkedin-scrapy
===============

An incomplete web crawler which scrapes every LinkedIn public profile using the Scrapy Python library
