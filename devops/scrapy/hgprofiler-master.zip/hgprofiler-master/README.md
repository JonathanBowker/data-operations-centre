Usage:

1) Create a file usernames.txt line-separated usernames
2) ./run.bash

Requirements:

scrapy (pip install scrapy)